package com.armaan.academyapi.dto.update;

import java.time.LocalDate;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaymentUpdateDto {

     private Long enrollmentId;   // Link payment to a student enrollment
    private Double amount;
    private LocalDate paymentDate;
    private String status;       // PAID or PENDING
    private String paymentMode;  // e.g., CASH, CARD, ONLINE
}